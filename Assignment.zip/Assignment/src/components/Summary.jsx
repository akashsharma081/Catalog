import React from 'react'

export default function Summary() {
  return (
    <h1 style={{padding:"0 50px 0 50px"}}>Welcome to Summary</h1>
  )
}
