import React from 'react'

export default function Setting() {
  return (
    <h1 style={{padding:"0 50px 0 50px"}}>Welcome to Setting</h1 >
  )
}
