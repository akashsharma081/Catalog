import React from 'react'

export default function Statistics() {
  return (
    <h1 style={{padding:"0 50px 0 50px"}}>Welcome to Statistics</h1>
  )
}
